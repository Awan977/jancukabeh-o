Source code ini berisi materi yang telah dibuat tentang bagaimana cara download dan integrasi slider ke dalam project berbasis website yang dibuat.
